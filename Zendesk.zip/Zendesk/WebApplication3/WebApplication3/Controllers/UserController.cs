﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication3.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication3.Controllers
{
    [Route("api/User")]
    [ApiController]
 
    public class UserController : ControllerBase
    {
        private readonly UserContext _context;
       
        public UserController(UserContext context)
        {
            _context = context;

            if (_context.Users.Count() == 0)
            {
                // Create a new TodoItem if collection is empty,
                // which means you can't delete all TodoItems.
                _context.Users.Add(new Users { UserName = "Item1", OTP = "Item2", Password = "2CA2764C00B8B91876703CB48E8B9EFE9E5DE751622F530D8A7205BC62DCEA32C9AC234493429AAD772BBA41D862E35F34480243F802D6643A59EF4C24EB8B4C", Status = "Active", Id = 1 });
                _context.SaveChanges();
            }

        }
        // GET: api/Todo
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Users>>> GetTodoItems()
        {
            return await _context.Users.ToListAsync();
        }

        // GET: api/Todo/5
        [HttpPost]
        public async Task<ActionResult<Users>> UserInfo(Users item)
        {
          
                String username = item.UserName;
            String password = item.Password;
           String harshPassword=PasswordController.SHA512(password);
                List<Users> listA = new List<Users>();
            List<String> lines = new List<String>();
            String path= @"~/../UserDb.csv";
            Users user=null;
                   try
            {
                using (var reader = new StreamReader(path))
                {
                    String line = reader.ReadLine();
                    lines.Add(line);
                    while (!reader.EndOfStream)
                    {
                    
                       line = reader.ReadLine();
                        String[] values = line.Split(',');
                        if (username.Equals(values[0]) && harshPassword.Equals(values[1]) && values[2].Equals("Active"))
                        {
                            user = new Users();
                            user.UserName = values[0];
                           
                            user.Status = values[2];
                            values[3] = "0";
                            line = String.Join(",", values);
                            user.NoOfLogin = int.Parse(values[3]);

                            user.LastLogin = values[4];
                            listA.Add(user);
                        }else if(username.Equals(values[0]) && harshPassword.Equals(values[1])==false)
                        {
                            int counter = int.Parse(values[3]);
                            counter = counter + 1;
                            if (counter >= 4)
                            {
                                values[2] = "Ban";
                                line = String.Join(",", values);
                            }
                            values[3] = counter.ToString();
                            line = String.Join(",", values);
                        }

                        lines.Add(line);

                    }
                    reader.Close();
                    using (StreamWriter writer = new StreamWriter(path, false))
                    {
                        foreach (String newline in lines)
                            writer.WriteLine(newline);
                    }
                }
            }catch(Exception ex)
            {
                String a = ex.InnerException.Message;
            }
          
            var userPassword = user;

            if (userPassword == null)
            {
                return BadRequest("Invalid User");
            }
           

            return userPassword;
        }

       

      


    }

    }

