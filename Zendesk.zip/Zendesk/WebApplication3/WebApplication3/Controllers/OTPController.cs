﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    [Route("api/OTP")]
    [ApiController]
    public class OTPController : ControllerBase
    {
        private readonly UserContext _context;

        [HttpPost]
        public async Task<ActionResult<Users>> UserInfo(Users item)
        {

            String username = item.UserName;
            String OTP = item.OTP;
          
            List<Users> listA = new List<Users>();
            List<String> lines = new List<String>();
            String path = @"~/../UserDb.csv";
            Users user = null;
            try
            {
                using (var reader = new StreamReader(path))
                {
                    String line = reader.ReadLine();
                    lines.Add(line);
                    while (!reader.EndOfStream)
                    {

                        line = reader.ReadLine();
                        String[] values = line.Split(',');
                        if (username.Equals(values[0]) && OTP.Equals(values[5]))
                        {
                            user = new Users();
                            user.UserName = values[0];
                         
                            user.OTP = values[5];
                            values[5] = "0";
                            line = String.Join(",", values);
                            listA.Add(user);
                        }
                       

                        lines.Add(line);

                    }
                    reader.Close();
                    using (StreamWriter writer = new StreamWriter(path, false))
                    {
                        foreach (String newline in lines)
                            writer.WriteLine(newline);
                    }
                }
            }
            catch (Exception ex)
            {
                String a = ex.InnerException.Message;
            }

            var userPassword = user;

            if (userPassword == null)
            {
                return BadRequest("Invalid OTP");
            }


            return userPassword;
        }

    }
}