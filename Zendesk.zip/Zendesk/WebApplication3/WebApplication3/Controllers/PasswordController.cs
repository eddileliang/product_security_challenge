﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    [Route("api/pwd")]
    [ApiController]
    public class PasswordController : ControllerBase
    {
        private readonly UserContext _context;

        [HttpPost]
        public async Task<ActionResult<Users>> UserInfo(Users item)
        {

            String username = item.UserName;
            String OTP = item.OTP;
            String password = item.Password;
            String harshPassword = SHA512(password);

            List<Users> listA = new List<Users>();
            List<String> lines = new List<String>();
            String path = @"~/../UserDb.csv";
            Users user = null;
            try
            {
                using (var reader = new StreamReader(path))
                {
                    String line = reader.ReadLine();
                    lines.Add(line);
                    while (!reader.EndOfStream)
                    {

                        line = reader.ReadLine();
                        String[] values = line.Split(',');
                        if (username.Equals(values[0]) && OTP.Equals(values[5]))
                        {
                            user = new Users();
                            user.UserName = values[0];
                            values[1]=harshPassword;
                            line = String.Join(",", values);
                            user.OTP = values[5];
                            values[5] = "0";
                            line = String.Join(",", values);
                            listA.Add(user);
                        }


                        lines.Add(line);

                    }
                    reader.Close();
                    using (StreamWriter writer = new StreamWriter(path, false))
                    {
                        foreach (String newline in lines)
                            writer.WriteLine(newline);
                    }
                }
            }
            catch (Exception ex)
            {
                String a = ex.InnerException.Message;
            }

            var userPassword = user;

            if (userPassword == null)
            {
                return BadRequest("Invalid OTP");
            }


            return userPassword;
        }
        public static string SHA512(string input)
        {
            var bytes = System.Text.Encoding.UTF8.GetBytes(input);
            using (var hash = System.Security.Cryptography.SHA512.Create())
            {
                var hashedInputBytes = hash.ComputeHash(bytes);

                // Convert to text
                // StringBuilder Capacity is 128, because 512 bits / 8 bits in byte * 2 symbols for byte 
                var hashedInputStringBuilder = new System.Text.StringBuilder(128);
                foreach (var b in hashedInputBytes)
                    hashedInputStringBuilder.Append(b.ToString("X2"));
                return hashedInputStringBuilder.ToString();
            }
        }
    }
}